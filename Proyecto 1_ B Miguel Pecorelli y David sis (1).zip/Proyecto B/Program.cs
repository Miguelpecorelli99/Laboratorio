// Proyecto 1: Parte B - Sistema de Car Wash
// Realizado por: Miguel Pecorelli 1197326 | David Sis 1210426

Console.WriteLine("Proyecto 1: Parte B");
Console.WriteLine("Realizado por los integrantes: \n Miguel Pecorelli 1197326 \n David Sis 1210426");
Console.WriteLine();

// ===== DECLARACION E INICIALIZACION DE VARIABLES =====
int opcion, tipovehiculo, ticketactivo, numeroclientes, cobro, opcion2, servicioextra, clientesconservicioextra;
float tarifa, totalrecaudado;
string operador, placa, nombrecliente;

opcion = 0;
tipovehiculo = 0;
ticketactivo = 0;
numeroclientes = 0;
cobro = 0;
servicioextra = 0;          // 0 = sin servicio extra, 1 = con servicio extra
clientesconservicioextra = 0;
tarifa = 0;
totalrecaudado = 0;
operador = "";
placa = "";
nombrecliente = "";

// Solicitar nombre del operador al iniciar
Console.WriteLine("Ingrese su nombre de operador:");
operador = Console.ReadLine().Trim();
Console.WriteLine($"\nBienvenido, {operador}!\n");

// ===== MENU PRINCIPAL - ciclo que se repite hasta que el operador elija salir =====
while (opcion != 5)
{
    Console.WriteLine("========== MENU DE OPCIONES ==========");
    Console.WriteLine(" 1. Crear ticket de entrada");
    Console.WriteLine(" 2. Lavado de llantas y rines");
    Console.WriteLine(" 3. Consultar monto a cobrar");
    Console.WriteLine(" 4. Registrar salida y calcular cobro");
    Console.WriteLine(" 5. Salir del programa");
    Console.WriteLine("======================================");
    Console.WriteLine("Elija una opcion:");

    // Validar que la opcion del menu sea un numero valido
    if (!int.TryParse(Console.ReadLine().Trim(), out opcion))
    {
        Console.WriteLine("Error: ingrese un número del 1 al 5.\n");
        opcion = 0;
        continue;
    }

    switch (opcion)
    {
        // ===== CASE 1: CREAR TICKET DE ENTRADA =====
        case 1:
            {
                // No se permite crear ticket si ya hay uno activo
                if (ticketactivo == 1)
                {
                    Console.WriteLine($"\nYa existe un ticket activo para la placa {placa}.");
                    Console.WriteLine("Debe registrar la salida del vehículo actual antes de crear uno nuevo.\n");
                    break;
                }

                // Pedir nombre del cliente
                Console.WriteLine("Ingrese el nombre del cliente:");
                nombrecliente = Console.ReadLine().Trim();

                // Pedir placa con validacion: exactamente 6 caracteres y sin espacios
                Console.WriteLine("Ingrese la placa del vehiculo (6 caracteres, sin espacios):");
                placa = Console.ReadLine().ToUpper().Trim();

                while (placa.Contains(" ") || placa.Length != 6)
                {
                    Console.WriteLine($"Placa inválida (ingresaste {placa.Length} caracteres). Debe tener exactamente 6 caracteres y sin espacios:");
                    placa = Console.ReadLine().ToUpper().Trim();
                }

                // Pedir tipo de vehiculo con validacion
                Console.WriteLine("Ingrese el tipo de vehiculo:\n 1. Sedan\n 2. Pickup o SUV");
                tipovehiculo = 0;

                while (tipovehiculo != 1 && tipovehiculo != 2)
                {
                    if (int.TryParse(Console.ReadLine().Trim(), out tipovehiculo))
                    {
                        switch (tipovehiculo)
                        {
                            case 1:
                                tarifa = 50;
                                Console.WriteLine("Tipo: Sedan.");
                                break;
                            case 2:
                                tarifa = 75;
                                Console.WriteLine("Tipo: Pickup o SUV.");
                                break;
                            default:
                                Console.WriteLine("Ingrese un número válido [1 o 2]:");
                                tipovehiculo = 0;
                                break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error: debe ingresar un número [1 o 2]:");
                        tipovehiculo = 0;
                    }
                }

                // Marcar ticket como activo y confirmar
                ticketactivo = 1;
                Console.WriteLine($"\nTicket creado exitosamente.");
                Console.WriteLine($"  Cliente : {nombrecliente}");
                Console.WriteLine($"  Placa   : {placa}");
                Console.WriteLine($"  Tarifa  : Q{tarifa}\n");
                break;
            }

        // ===== CASE 2: LAVADO DE LLANTAS Y RINES =====
        case 2:
            {
                // Verificar que haya un ticket activo
                if (ticketactivo == 0)
                {
                    Console.WriteLine("\nNo hay ticket activo. Primero debe crear un ticket de entrada.\n");
                    break;
                }

                // Si ya tiene servicio extra, bloquear y mostrar mensaje de error
                if (servicioextra == 1)
                {
                    Console.WriteLine("Este vehículo ya cuenta con servicio de lavado de rines.");
                    Console.WriteLine("No se puede agregar otro servicio extra.\n");
                    break;
                }

                // Si no tiene servicio extra, agregarlo
                int numeroderin = 0;
                bool rinValido = false;

                Console.WriteLine("\nIngrese el tamaño de los rines (12 a 22):");

                // Validar tamaño de rin y asignar cobro correspondiente
                while (!rinValido)
                {
                    if (int.TryParse(Console.ReadLine().Trim(), out numeroderin))
                    {
                        if (numeroderin >= 12 && numeroderin <= 16)
                        {
                            cobro = 30;
                            rinValido = true;
                        }
                        else if (numeroderin >= 17 && numeroderin <= 19)
                        {
                            cobro = 40;
                            rinValido = true;
                        }
                        else if (numeroderin >= 20 && numeroderin <= 22)
                        {
                            cobro = 60;
                            rinValido = true;
                        }
                        else
                        {
                            Console.WriteLine("Rin fuera de rango (12–22). Intente de nuevo:");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error: debe ingresar un número entre 12 y 22:");
                    }
                }

                // Marcar servicio extra como activo
                servicioextra = 1;
                Console.WriteLine($"\nServicio extra agregado. Lavado de rines: Q{cobro}");
                Console.WriteLine($"Total actual: Q{tarifa + cobro}\n");
                break;
            }

        // ===== CASE 3: CONSULTAR MONTO A COBRAR =====
        case 3:
            {
                if (ticketactivo == 0)
                {
                    Console.WriteLine("\nNo hay ticket activo.\n");
                    break;
                }

                // Mostrar detalle desglosado del cobro
                Console.WriteLine("\n------ DETALLE DE COBRO ------");
                Console.WriteLine($"  Cliente             : {nombrecliente}");
                Console.WriteLine($"  Placa               : {placa}");
                Console.WriteLine($"  Tarifa base         : Q{tarifa}");

                if (servicioextra == 1)
                    Console.WriteLine($"  Lavado de rines     : Q{cobro}");
                else
                    Console.WriteLine("  Servicio extra      : No aplica");

                Console.WriteLine("------------------------------");
                Console.WriteLine($"  TOTAL A COBRAR      : Q{tarifa + cobro}");
                Console.WriteLine("------------------------------\n");
                break;
            }

        // ===== CASE 4: REGISTRAR SALIDA Y CALCULAR COBRO =====
        case 4:
            {
                // Solo se permite si existe un ticket activo
                if (ticketactivo == 0)
                {
                    Console.WriteLine("\nNo hay ningún ticket activo. Primero debe crear un ticket de entrada.\n");
                    break;
                }

                // Mostrar resumen final desglosado
                Console.WriteLine("\n========== RESUMEN DE COBRO ==========");
                Console.WriteLine($"  Cliente      : {nombrecliente}");
                Console.WriteLine($"  Placa        : {placa}");

                if (tipovehiculo == 1)
                    Console.WriteLine("  Tipo         : Sedan");
                else
                    Console.WriteLine("  Tipo         : Pickup o SUV");

                Console.WriteLine($"  Tarifa base  : Q{tarifa}");

                if (servicioextra == 1)
                {
                    Console.WriteLine($"  Lavado rines : Q{cobro}");
                    Console.WriteLine($"  TOTAL        : Q{tarifa + cobro}");
                }
                else
                {
                    Console.WriteLine("  Sin servicio extra");
                    Console.WriteLine($"  TOTAL        : Q{tarifa}");
                }
                Console.WriteLine("======================================\n");

                // Acumular estadisticas de la sesion
                totalrecaudado = totalrecaudado + tarifa + (servicioextra == 1 ? cobro : 0);
                numeroclientes++;

                if (servicioextra == 1)
                    clientesconservicioextra++;

                // Mini-juego de premio sorpresa
                Console.WriteLine("¡Participa en nuestra dinámica de premio sorpresa!");
                Console.WriteLine("Elige un número del 1 al 3:");

                int numeroCliente = 0;
                while (numeroCliente < 1 || numeroCliente > 3)
                {
                    if (int.TryParse(Console.ReadLine().Trim(), out numeroCliente))
                    {
                        if (numeroCliente < 1 || numeroCliente > 3)
                            Console.WriteLine("Número inválido. Elige entre 1 y 3:");
                    }
                    else
                    {
                        Console.WriteLine("Error: ingresa un número válido (1, 2 o 3):");
                        numeroCliente = 0;
                    }
                }

                // Generar numero aleatorio y comparar con el del cliente
                Random rnd = new Random();
                int numeroAleatorio = rnd.Next(1, 4);
                Console.WriteLine($"\nEl número ganador es: {numeroAleatorio}");

                if (numeroCliente == numeroAleatorio)
                    Console.WriteLine("¡Felicidades! ¡Ganaste un descuento del 20% en tu próxima visita!\n");
                else
                    Console.WriteLine("¡Gracias por participar! Suerte la próxima vez.\n");

                // Reiniciar todos los datos para el siguiente vehiculo
                ticketactivo = 0;
                tipovehiculo = 0;
                tarifa = 0;
                cobro = 0;
                servicioextra = 0;
                nombrecliente = "";
                placa = "";

                Console.WriteLine("Datos reiniciados. Listo para el siguiente vehículo.\n");
                break;
            }

        // ===== CASE 5: SALIR DEL PROGRAMA =====
        case 5:
            {
                // Mostrar reporte final de la sesion
                Console.WriteLine("\n========== REPORTE FINAL DE SESION ==========");
                Console.WriteLine($"  Operador                  : {operador}");
                Console.WriteLine($"  Vehículos atendidos       : {numeroclientes}");
                Console.WriteLine($"  Con servicio extra        : {clientesconservicioextra}");
                Console.WriteLine($"  Total recaudado           : Q{totalrecaudado}");
                Console.WriteLine("==============================================");
                Console.WriteLine("\n¡Hasta luego!\n");
                break;
            }

        default:
            Console.WriteLine("\nOpción inválida. Elija un número del 1 al 5.\n");
            break;
    }
}